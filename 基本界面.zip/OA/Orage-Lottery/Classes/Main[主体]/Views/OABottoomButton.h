//
//  OABottoomButton.h
//  Orage-Lottery
//
//  Created by 黄坤 on 16/5/10.
//  Copyright © 2016年 wzpnyg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OABottoomButton : UIButton

@end
