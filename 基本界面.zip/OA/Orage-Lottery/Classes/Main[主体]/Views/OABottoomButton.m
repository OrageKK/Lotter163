//
//  OABottoomButton.m
//  Orage-Lottery
//
//  Created by 黄坤 on 16/5/10.
//  Copyright © 2016年 wzpnyg. All rights reserved.
//

#import "OABottoomButton.h"

@implementation OABottoomButton


/**
 *
 *  屏蔽自己的自灰效果
 *
 */

- (void)setHighlighted:(BOOL)highlighted{
    
}
@end
